#include <iostream>
#include <string>
#include <sstream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void inttostring(int num,string &str)  //����ת�ַ��� 
{
	stringstream s;
	s<<num;
	s>>str;
}
void stringtoconstchar(string str,const char* &ch) //string ת const char* 
{
	ch=str.c_str();
}
void chartoconstchar(char* ch,const char* &constc)  //char* ת const char*
{
	constc=ch;
}
void chartostring(char* ch,string &str) //char* ת string 
{
	str=ch;
}
int main(int argc, char* argv[]) 
{
	const char* cmd;
	char* ch;
	string str="",str2="";
	for(int i=1;i<argc;i++)
	{
		ch=argv[i];
		chartostring(ch,str2);
		str="md ����վ"+str2+".{645FF040-5081-101B-9F08-00AA002F954E}";
		stringtoconstchar(str,cmd);
		system(cmd);
	}
	return 0;
}
