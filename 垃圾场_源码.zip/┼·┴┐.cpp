#include<iostream>
#include<sstream>
#include<string> 
using namespace std;
void inttostring(int num,string &str)  //����ת�ַ��� 
{
	stringstream s;
	s<<num;
	s>>str;
}
void stringtoconstchar(string str,const char* &ch) //string ת const char* 
{
	ch=str.c_str();
}
int main()
{
	int geshu;
	const char* cmd;
	string temp,temp2;
	cout<<"Ҫ���ɶ��ٸ�����վ��";
	cin>>geshu;
	for(int i=1;i<=geshu;i++)
	{
		temp="������.exe ";
		inttostring(i,temp2);
		temp+=temp2;
		stringtoconstchar(temp,cmd);
		system(cmd);
	}
}
